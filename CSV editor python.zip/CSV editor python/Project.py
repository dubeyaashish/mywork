# Id: 6313771
# Name: Aashish Dubey
import AcademicModule as AM

print("Aca Version 1.0 \n\
PERSONAL ACADEMIC RECORDS\n\
--------------------------\n\
1. Add new academic record.\n\
2. Remove a specific academic record.\n\
3. Display academic records by semester.\n\
4. Display academic records by grade result.\n\
5. Display the number of courses for each grade results.\n\
6. Update a grade result to a specific academic record.\n\
7. Calculate the overall G.P.A. and total credits\n\
0. Exit the program\n\
--------------------------\n\
Enter optional (1-7, 0 to Exit) **Upper case only **")

print("Please enter option : " )

name = input()

while name != "0":
    if name == "1":
        AM.add_new_academic()
        break
    if name == "2":
        AM.delete()
        break
    if name == "3": 
        AM.display_academic_record_by_semester()
        break
    if name == "4":
        AM.display_by_grade_result()
        break
    if name == "5":
        AM.display_courses_for_each_grade_result()
        break
    if name == "6":
        AM.update_to_specific_record()
        break
    if name == "7":
        AM.Calculate_and_display_GPA_credits()
        break
print("Exit program completed.")
