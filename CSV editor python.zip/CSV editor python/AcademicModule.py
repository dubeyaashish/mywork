# Id: 6313771
# Name: Aashish Dubey

import ReadWriteModule as df
import csv


def add_new_academic():#1 #workingproperly
    
    new_academic = []
    academic_year = input('Enter academic year : ')
    while len(academic_year) != 4:
            print("Error.Please ckech your academic year!")
            academic_year = input('Enter academic year : ')
    new_academic.append(academic_year)

    academic_term = input('Enter academic term : ')
    while academic_term != "1" and academic_term != "2" and academic_term != "3":
            print("Error.Please check your academic term!")
            academic_term = input('Enter academic term : ')
    new_academic.append(academic_term)

    academic_course_code = input('Enter academic course code : ')
    while len(academic_course_code) != 6 and len(academic_course_code) != 7:
            print("Error.Please ckech your academic course code!")
            academic_course_code = input('Enter academic course code : ')
            academic_course_code = academic_course_code.upper()
    new_academic.append(academic_course_code)

    academic_section_number = input('Enter academic section number : ')
    while len(academic_section_number) != 3:
            print("Error.Please ckech your academic section number!")
            academic_section_number = input('Enter academic section number : ')
    new_academic.append(academic_section_number)

    academic_grade_result = input('Enter academic grade result : ' )
    while academic_grade_result.upper() != "A" and academic_grade_result.upper() != "B" and academic_grade_result.upper() != "C" and academic_grade_result.upper() != "D" and academic_grade_result.upper() != "E" and academic_grade_result.upper() != "F":
            print("Error.Please ckech your academic grade result!")
            academic_grade_result = input('Enter academic grade result : ')
    new_academic.append(academic_grade_result)

    academic_course_credit = input('Enter academic course credit : ')
    while academic_course_credit != "1" and academic_course_credit != "2" and academic_course_credit != "3": 
            print("Error.Please ckech your academic course credit!")
            academic_course_credit = input('Enter academic course credit : ')
    new_academic.append(academic_course_credit)

    record = df.readFile("academicrecords")
    found = False
    for i in record:
        j = 0
    while j<=2 and not found:
          if new_academic[j] != i[j]:
                break
          j+=1
    else:
          found = True
    if found:
        print("file already exist")
    else:
        record.append(new_academic)
        df.write("academicrecords",record)

def delete():#2 #workingproperly
    record = df.readFile("academicrecords")
    member = str(input("Enter course code"))
    for i in range(len(record)):
        if record[i][2] == member:
                record.pop(i)
                df.write("academicrecords",record)
                print(member, "removed")
                break
                
    else:
          print('Error:', member, 'does not exist in the file!')


def display_academic_record_by_semester():#3 #workingproperly
    semester = ""
    records = df.readFile("academicrecords")
    if len(records)!=0:
        for row in records:
            currentsem = f"{row[1]}/{row[0]}"
            if semester != currentsem:
                semester = currentsem
                print(f"\nSemester {semester}")
            print(f"{row[2]}\t({row[3]})\t{row[4]}")
    else:
        print("No academic records found!")


def display_by_grade_result():#4 #workingproperly
   records = df.readFile("academicrecords")
   x = input("Enter grade result: ")
   found = False
   for row in records:
        if row[4]==x:
          print(f"{row[2]}\t\t({row[3]})\t{row[4]}")
          found = True
        if not found:
          print("Error: No academic records found")

def display_courses_for_each_grade_result():#5 #workingproperly
    records = df.readFile("academicrecords")
    gradelist = []
    for row in records:
      gradelist.append(row[4])
      A = gradelist.count("A")
      Aminus = gradelist.count("A-")
      Aplus = gradelist.count("A+")
      B = gradelist.count("B")
      Bminus = gradelist.count("B-")
      Bplus = gradelist.count("B+")
      S = gradelist.count("S")
    print("GRADE A:",A)
    print("GRADE A-:",Aminus)
    print("GRADE A+:",Aplus)
    print("GRADE B:",B)
    print("GRADE B-:",Bminus)
    print("GRADE B+:",Bplus)
    print("GRADE S:",S)

def update_to_specific_record(): #6 #working properly
    records = df.readFile("academicrecords")
    year = input("Enter academic year: ")
    term = input("Enter academic term: ")
    code = input("Enter course code: ")
    for i in range(len(records)):
      if year == records[i][0] and term == records[i][1] and code == records[i][2]:
          grade = input("Enter grade result: ")
          records[i][4] = grade
          df.write("academicrecords", records)
          print(f"Updated grade result on {code} as {grade}")
          break
    else:
          print(f"Error: {code} does not exist in the file!")
          

def Calculate_and_display_GPA_credits():#7 #workingproperly
    score = {
     "A": 4.00,
     "A-": 3.75,
     "B+": 3.25,
     "B": 3.00,
     "B-": 2.75,
     "C+": 2.25,
     "C": 2.00,
     "C-": 1.75,
     "D": 1.00,
     "F":1.00,
     }
    records = df.readFile("academicrecords")
    grade = 0
    credit = 0
    for row in records:
        grade += score.setdefault(row[4], 0)*int(row[5])
        credit +=  int(row[5])
    grade = grade/credit
    print(f"GPA: {grade}")
    print(f"Credit: {credit}")
    
