<?php
	session_start();
?>
<html>
	<head>
		<title>Staff Details</title>
	</head>
	<body>
		<?php
			if(isset($_POST['Submit']))
			{
				$data_missing=array();
				if(empty($_POST['Staff_id']))
				{
					$data_missing[]='Staff id';
				}
				else
				{
					$Staff_id=trim($_POST['Staff_id']);
				}

				if(empty($_POST['Staff_Name']))
				{
					$data_missing[]='Staff Name';
				}
				else
				{
					$Staff_Name=$_POST['Staff_Name'];
				}

				if(empty($_POST['Staff_Number']))
				{
					$data_missing[]='Staff Number';
				}
				else
				{
					$Staff_Number=trim($_POST['Staff_Number']);
				}

				if(empty($_POST['Job_type']))
				{
					$data_missing[]='Job Type';
				}
				else
				{
					$Job_type=trim($_POST['Job_type']);
				}
	
                if(empty($_POST['Staff_gateNo']))
				{
					$data_missing[]='Gate No';
				}
				else
				{
					$Staff_gateNo=trim($_POST['Staff_gateNo']);
				}

				if(empty($_POST['Staff_salary']))
				{
					$data_missing[]='Salary';
				}
				else
				{
					$Staff_salary=$_POST['Staff_salary'];
				}
				if(empty($_POST['active']))
				{
					$data_missing[]='active';
				}
				else
				{
					$active=$_POST['active'];
				}
				if(empty($_POST['Airline']))
				{
					$data_missing[]='Airline';
				}
				else
				{
					$Airline=$_POST['Airline'];
				}

				if(empty($data_missing))
				{
					require_once('Database Connection file/mysqli_connect.php');
					$query="INSERT INTO staff_details (Staff_id,Staff_Name,Staff_Number,Job_type,Staff_gateNo,Staff_salary,active,Airline) VALUES (?,?,?,?,?,?,?,?)";
					$stmt=mysqli_prepare($dbc,$query);
					mysqli_stmt_bind_param($stmt,"ssssssss",$Staff_id,$Staff_Name,$Staff_Number,$Job_type,$Staff_gateNo,$Staff_salary,$active,$Airline);
					mysqli_stmt_execute($stmt);
					$affected_rows=mysqli_stmt_affected_rows($stmt);
					//echo $affected_rows."<br>";
					// mysqli_stmt_bind_result($stmt,$cnt);
					// mysqli_stmt_fetch($stmt);
					// echo $cnt;
					print_r($stmt);
					mysqli_stmt_close($stmt);
					mysqli_close($dbc);
					/*
					$response=@mysqli_query($dbc,$query);
					*/
					if($affected_rows==1)
					{
						header('location:newstaff.php');
					}
					else
					{
						echo "Submit Error";
						echo "mysqli_error";
					}
				}
				else
				{
					echo "The following data fields were empty! <br>";
					foreach($data_missing as $missing)
					{
						echo $missing ."<br>";
					}
				}
			}
			else
			{
				echo "Submit request not received";
			}
		?>
	</body>
</html>