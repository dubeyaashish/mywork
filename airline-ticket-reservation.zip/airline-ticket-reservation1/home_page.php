<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to our airlines</title>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<link rel="stylesheet" href="indexaboutus.css">
	</head>
	<body>
	<style type="text/css">


body{
font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
}
* {
box-sizing: border-box;
}
.openChatBtn {
background-color: rgb(123, 28, 179);
color: white;
padding: 16px 20px;
border: none;
font-weight: 500;
font-size: 18px;
cursor: pointer;
opacity: 0.8;
position: fixed;
bottom: 23px;
right: 28px;
width: 280px;
}
.openChat {
display: none;
position: fixed;
bottom: 0;
right: 15px;
border: 3px solid #ff08086b;
z-index: 9;
}
form {
max-width: 300px;
padding: 10px;
background-color: white;
}
form textarea {
width: 100%;
font-size: 18px;
padding: 15px;
margin: 5px 0 22px 0;
border: none;
font-weight: 500;
background: #d5e7ff;
color: rgb(0, 0, 0);
resize: none;
min-height: 200px;
}
form textarea:focus {
background-color: rgb(219, 255, 252);
outline: none;
}
form .btn {
background-color: rgb(34, 197, 107);
color: white;
padding: 16px 20px;
font-weight: bold;
border: none;
cursor: pointer;
width: 100%;
margin-bottom: 10px;
opacity: 0.8;
}
form .close {
background-color: red;
}
form .btn:hover, .openChatBtn:hover {
opacity: 1;
}
.adm a{
color:rgb(46, 46, 173);
}
.as{
color:rgb(46, 46, 173);
}

</style>
	
		<div class = "header">
			<nav>
			<img src = "images/JAP.png" class = "logo">
	        <ul class = "nav-link">
			<body>
				<li><a href="home_page.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
				<li>
					<?php
						if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Customer')
						{
							echo "<a href=\"book_tickets.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
						}
						else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Administrator')
						{
							echo "<a href=\"admin_ticket_message.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
						}
						else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Staff')
						{
							echo "<a href=\"Staff_homepage.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> My Profile</a>";
						}
						else
						{
							echo "<a href=\"login_page.php\"><i class=\"fa fa-ticket\" aria-hidden=\"true\"></i> Book Tickets</a>";
						}
					?>
				</li>
				<li><a href="indexAboutUs.html"><i class="fa fa-plane" aria-hidden="true"></i> About Us</a></li>
				<li><a href="indexcontactus.html"><i class="fa fa-phone" aria-hidden="true"></i> Contact Us</a></li>
				<li>
					<?php
						if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Customer')
						{
							echo "<a href=\"customer_homepage.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
						}
						else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Administrator')
						{
							echo "<a href=\"admin_homepage.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
						}
						else if(isset($_SESSION['login_user'])&&$_SESSION['user_type']=='Staff')
						{
							echo "<a href=\"Staff_homepage.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
						}
						else
						{
							echo "<a href=\"login_page.php\"><i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> Login</a>";
						}
					?>
				</li>
				</nav>
&nbsp; 	&nbsp;
<div class = "header"> 
      
	  <div class="text-left" >
	   <h1 class="text-danger"><b>Welcome to our Airline</b></h1>
	   <form action="home.php" method="post"></form>
	  </div>
	  
	  <div class="wrapper">
	  <nav>
		<img src = "images/airport.jpg" width="900" height="600">
	   
	  </nav>
	  &nbsp; 	&nbsp;

		</div>		
		
		</div>

		<button class="openChatBtn" onclick="openForm()">Chat</button>
<div class="openChat">
<form>
<h1>Chat</h1>
<label for="msg"><b>Message</b></label>
<textarea placeholder="Type message.." name="msg" required></textarea>
<button type="submit" class="btn">Send</button>
<button type="button" class="btn close" onclick="closeForm()">
Close
</button>
</form>
</div>
<script>
  document .querySelector(".openChatBtn") .addEventListener("click", openForm);
  document.querySelector(".close").addEventListener("click", closeForm);
  function openForm() {
      document.querySelector(".openChat").style.display = "block";
  }
  function closeForm() {
      document.querySelector(".openChat").style.display = "none";
  }
</script>
        

	</body>
</html>