<?php
	session_start();
?>
<html>
	<head>
		<title>
			Account Login
		</title>
		<style>
			input {
    			border: 1.5px solid #030337;
    			border-radius: 4px;
    			padding: 7px 30px;
			}
			input[type=submit] {
				background-color: #030337;
				color: white;
    			border-radius: 4px;
    			padding: 7px 45px;
    			margin: 0px 60px
			}
		</style>
		
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="login_page.css">
	</head>
	<body>
  <div class = "header"> 
    <nav>
      <img src = "images/JAP.png"  class = "logo">
      <ul class = "nav-link">
        <body>
          <li><a href="index.html"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li>
            <li><a href="login_page.php"><i class="fa fa-ticket" aria-hidden="true"></i>Book Tickets</a></li>
            <li><a href="login_page.php"><i class="fa fa-sign-in" aria-hidden="true"></i>Login</a></li>
            <li> <a href="new_user.php"><i class="fa fa-sign-in" aria-hidden="true"></i>Sign Up</a></li>
              <li> <a href="indexcontactus.html"><i class="fa fa-phone" aria-hidden="true"></i>Contact us</a></li>
                <li><a href="indexAboutUs.html"><i class="fa fa-plane" aria-hidden="true"></i> About Us</a></li>
        </ul>
    </li>
</nav>
&nbsp; 	&nbsp;
	
		<br>
		<br>
		<br>
		<form class="float_form" style="padding-left: 40px" action="login_handler.php" method="POST">
			<fieldset>
				<legend>Login Details:-</legend>
				<strong>Username:</strong><br>
				<input type="text" name="username" placeholder="Enter your username" required><br><br>
				<strong>Password:</strong><br>
				<input type="password" name="password" placeholder="Enter your password" required><br><br>
				<strong>User Type:</strong><br>
				Customer <input type='radio' name='user_type' value='Customer' checked/> Administrator <input type='radio' name='user_type' value='Administrator'/>
				Staff <input type='radio' name='user_type' value='staff' checked/><br>
				<br>
				<?php
					if(isset($_GET['msg']) && $_GET['msg']=='failed')
					{
						echo "<br>
						<strong style='color:red'>Invalid Username/Password</strong>
						<br><br>";
					}
				?>
				<input type="submit" name="Login" value="Login">
			</fieldset>
			<br>
			<a href="new_user.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Create New User Account?</a>
			</div>
		</form>
	</body>
</html>