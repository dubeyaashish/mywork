<?php
DEFINE('DB_USER','root');
DEFINE('DB_PASSWORD','');
DEFINE('DB_HOST','localhost');
DEFINE('DB_NAME','airline_reservation');

$dbc=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME)
OR die('Could not connect to MySQL:' .
	mysqli_connect_error());

// SQL query to select data from database
$query = "SELECT * FROM staff_details ORDER BY Staff_id ASC";
$stmt = mysqli_prepare($dbc,$query);
$result = mysqli_query($dbc, $query);

?>

<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <title>Staff</title>
    <!-- CSS FOR STYLING THE PAGE -->
    <style>
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
  
        h1 {
            text-align: left;
            color: #006600;
            font-size: xx-large;
            font-family: 'Gill Sans', 'Gill Sans MT', 
            ' Calibri', 'Trebuchet MS', 'sans-serif';
        }
  
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
        }
  
        th,
        td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }
  
        td {
            font-weight: lighter;
        }
      
        </style>
        <link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
	</head>
	<body>
		<img class="logo" src="images/shutterstock_22.jpg"/> 
		<h1 id="title">
			JAP Airport
		</h1>
		<div>
			<ul>
				<li><a href="admin_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
				<li><a href="admin_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
				<li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
			</ul>
		</div>
  
<body>
    <section>
        <h1>Staff</h1>
   
        <!-- TABLE CONSTRUCTION-->
        <table align="left">
            <tr>
	
		  <tr>
		   <th>Staff ID</th>
		   <th>Staff Name</th>
		   <th>Staff Number</th>
		   <th>Job type</th>
		   <th>Gate Number</th>
		   <th>Status</th>
		   <th>Salary</th>
           <th>Airline</th>
	   </tr>
	     <!-- PHP CODE TO FETCH DATA FROM ROWS-->
		 <?php   // LOOP TILL END OF DATA 
                while($rows=$result->fetch_assoc())
                {
             ?>
     <!--FETCHING DATA FROM EACH 
                    ROW OF EVERY COLUMN-->
<td><?php echo $rows['Staff_id'];?></td>

<td><?php echo $rows['Staff_Name'];?></td>

<td><?php echo $rows['Staff_Number'];?></td>

<td><?php echo $rows['Job_type'];?></td>

<td><?php echo $rows ['Staff_gateNo'];?></td>

<td><?php echo $rows ['active'];?></td>

<td><?php echo $rows ['Staff_salary']?></td>

<td><?php echo $rows ['Airline']?></td>

</tr>

<?php

}

?>

</table>

</section>

</body>

</html>
          
        </table>
    </section>
</body>
  
</html>